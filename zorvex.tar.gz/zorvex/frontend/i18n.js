import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

// Translation resources
const resources = {
  en: {
    translation: {
      products: 'Products',
      chat: 'Chat',
      login: 'Login',
      register: 'Register',
      newProduct: 'New Product',
      name: 'Name',
      description: 'Description',
      price: 'Price',
      file: 'File',
      create: 'Create',
      logout: 'Logout',
      buyNow: 'Buy Now',
      messagePlaceholder: 'Type your message...',
      send: 'Send'
    }
  },
  ar: {
    translation: {
      products: 'المنتجات',
      chat: 'الدردشة',
      login: 'تسجيل الدخول',
      register: 'إنشاء حساب',
      newProduct: 'منتج جديد',
      name: 'الاسم',
      description: 'الوصف',
      price: 'السعر',
      file: 'الملف',
      create: 'إنشاء',
      logout: 'تسجيل الخروج',
      buyNow: 'اشتر الآن',
      messagePlaceholder: 'اكتب رسالتك...',
      send: 'إرسال'
    }
  }
};

i18n.use(initReactI18next).init({
  resources,
  lng: 'en',
  fallbackLng: 'en',
  interpolation: { escapeValue: false }
});

export default i18n;