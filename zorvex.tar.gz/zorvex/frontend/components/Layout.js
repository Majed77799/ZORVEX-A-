import Link from 'next/link';
import { useTranslation } from 'react-i18next';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';

/**
 * Layout component wrapping all pages.  It shows a basic navigation bar and
 * handles language switching via the locale in the URL.  User state is read
 * from localStorage for demonstration purposes.
 */
export default function Layout({ children }) {
  const { t, i18n } = useTranslation();
  const router = useRouter();
  const [user, setUser] = useState(null);

  useEffect(() => {
    // On mount, check if a token and user info exists in localStorage
    const stored = localStorage.getItem('zorvexUser');
    if (stored) setUser(JSON.parse(stored));
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('zorvexUser');
    setUser(null);
    router.push('/login');
  };

  const changeLanguage = (lng) => {
    i18n.changeLanguage(lng);
    router.push(router.pathname, router.asPath, { locale: lng });
  };

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: '1rem' }}>
      <nav style={{ display: 'flex', gap: '1rem', marginBottom: '1rem' }}>
        <Link href="/" locale={router.locale}>{t('products')}</Link>
        <Link href="/chat" locale={router.locale}>{t('chat')}</Link>
        {user?.role === 'admin' && <Link href="/admin/new-product" locale={router.locale}>{t('newProduct')}</Link>}
        {!user && <Link href="/login" locale={router.locale}>{t('login')}</Link>}
        {!user && <Link href="/register" locale={router.locale}>{t('register')}</Link>}
        {user && <button onClick={handleLogout}>{t('logout')}</button>}
        {/* Language toggles */}
        <button onClick={() => changeLanguage('en')}>EN</button>
        <button onClick={() => changeLanguage('ar')}>AR</button>
      </nav>
      <main>{children}</main>
    </div>
  );
}