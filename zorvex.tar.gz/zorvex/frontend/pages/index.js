import { useEffect, useState } from 'react';
import axios from 'axios';
import Link from 'next/link';
import { useTranslation } from 'react-i18next';
import { useRouter } from 'next/router';

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api';

export default function ProductsPage() {
  const { t } = useTranslation();
  const router = useRouter();
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function load() {
      try {
        const res = await axios.get(`${API_BASE}/products`);
        setProducts(res.data);
      } catch (err) {
        setError(err.response?.data?.message || err.message);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div>
      <h1>{t('products')}</h1>
      {router.query.cancelled && <p style={{ color: 'red' }}>Payment was cancelled.</p>}
      {router.query.success && <p style={{ color: 'green' }}>Thank you for your purchase!</p>}
      <ul>
        {products.map(prod => (
          <li key={prod._id} style={{ marginBottom: '1rem' }}>
            <Link href={`/products/${prod._id}`}>{prod.name} – ${prod.price}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}