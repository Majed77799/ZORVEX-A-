import { useRouter } from 'next/router';

export default function Success() {
  const router = useRouter();
  return (
    <div>
      <h1>Payment successful</h1>
      <p>Your payment was successful. You can now download your product from your email receipt.</p>
      <button onClick={() => router.push('/')}>Go back to products</button>
    </div>
  );
}