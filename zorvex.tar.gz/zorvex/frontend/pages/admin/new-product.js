import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import axios from 'axios';
import { useTranslation } from 'react-i18next';

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api';

export default function NewProduct() {
  const router = useRouter();
  const { t } = useTranslation();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [file, setFile] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    // check user role
    const stored = localStorage.getItem('zorvexUser');
    if (!stored) {
      router.push('/login');
    } else {
      const user = JSON.parse(stored);
      if (user.role !== 'admin') {
        router.push('/');
      }
    }
  }, [router]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const stored = localStorage.getItem('zorvexUser');
    const { token } = JSON.parse(stored);
    const formData = new FormData();
    formData.append('name', name);
    formData.append('description', description);
    formData.append('price', price);
    if (file) formData.append('file', file);
    try {
      await axios.post(`${API_BASE}/products`, formData, {
        headers: { Authorization: `Bearer ${token}` },
      });
      router.push('/');
    } catch (err) {
      setError(err.response?.data?.message || err.message);
    }
  };

  return (
    <div>
      <h1>{t('newProduct')}</h1>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit} encType="multipart/form-data">
        <div>
          <label>{t('name')}:</label>
          <input value={name} onChange={(e) => setName(e.target.value)} required />
        </div>
        <div>
          <label>{t('description')}:</label>
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} />
        </div>
        <div>
          <label>{t('price')}:</label>
          <input type="number" value={price} onChange={(e) => setPrice(e.target.value)} required />
        </div>
        <div>
          <label>{t('file')}:</label>
          <input type="file" onChange={(e) => setFile(e.target.files[0])} required />
        </div>
        <button type="submit">{t('create')}</button>
      </form>
    </div>
  );
}