import { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { useRouter } from 'next/router';
import { useTranslation } from 'react-i18next';

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api';

export default function ChatPage() {
  const router = useRouter();
  const { t } = useTranslation();
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    // Ensure user is logged in
    const stored = localStorage.getItem('zorvexUser');
    if (!stored) {
      router.push('/login');
    }
  }, [router]);

  useEffect(() => {
    // Scroll to bottom when messages change
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async () => {
    const text = input.trim();
    if (!text) return;
    const stored = JSON.parse(localStorage.getItem('zorvexUser'));
    setMessages(prev => [...prev, { role: 'user', content: text }]);
    setInput('');
    setLoading(true);
    try {
      const res = await axios.post(`${API_BASE}/chat`, { message: text }, {
        headers: { Authorization: `Bearer ${stored.token}` },
      });
      setMessages(prev => [...prev, { role: 'assistant', content: res.data.reply }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'assistant', content: err.response?.data?.message || err.message }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h1>{t('chat')}</h1>
      <div style={{ border: '1px solid #ccc', padding: '1rem', height: '50vh', overflowY: 'auto' }}>
        {messages.map((msg, idx) => (
          <div key={idx} style={{ textAlign: msg.role === 'user' ? 'right' : 'left', marginBottom: '0.5rem' }}>
            <strong>{msg.role === 'user' ? 'You' : 'AI'}:</strong> {msg.content}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>
      <div style={{ marginTop: '1rem' }}>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={t('messagePlaceholder')}
          style={{ width: '80%' }}
        />
        <button onClick={sendMessage} disabled={loading} style={{ marginLeft: '0.5rem' }}>
          {loading ? '...' : t('send')}
        </button>
      </div>
    </div>
  );
}