const Stripe = require('stripe');
const Product = require('../models/Product');
const User = require('../models/User');

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

/**
 * Create a Stripe checkout session for a single product.
 * Frontend should call this endpoint and redirect the user to the returned URL.
 */
exports.createCheckoutSession = async (req, res, next) => {
  try {
    const { productId } = req.body;
    if (!productId) return res.status(400).json({ message: 'Product ID is required' });
    const product = await Product.findById(productId);
    if (!product) return res.status(404).json({ message: 'Product not found' });

    // Create a checkout session
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'payment',
      line_items: [
        {
          price_data: {
            currency: 'usd',
            product_data: {
              name: product.name,
              description: product.description,
            },
            unit_amount: Math.round(product.price * 100),
          },
          quantity: 1,
        },
      ],
      customer_email: req.user.email,
      success_url: `${process.env.CLIENT_URL}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.CLIENT_URL}/products/${product._id}?cancelled=true`,
      metadata: { userId: req.user.id, productId: product._id.toString() },
    });
    res.json({ url: session.url });
  } catch (err) {
    next(err);
  }
};