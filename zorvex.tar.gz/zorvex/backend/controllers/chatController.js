const ChatMessage = require('../models/ChatMessage');
const { Configuration, OpenAIApi } = require('openai');

// Set up OpenAI client once
const configuration = new Configuration({ apiKey: process.env.OPENAI_API_KEY });
const openai = new OpenAIApi(configuration);

exports.sendMessage = async (req, res, next) => {
  try {
    const { message } = req.body;
    if (!message) return res.status(400).json({ message: 'Message is required' });

    // Save user message
    const userMsg = await ChatMessage.create({ userId: req.user.id, role: 'user', message });

    // Retrieve the last 10 messages for context
    const history = await ChatMessage.find({ userId: req.user.id })
      .sort({ createdAt: 1 })
      .limit(10)
      .select('role message -_id');

    // Format for ChatGPT
    const messages = history.map(m => ({ role: m.role, content: m.message }));
    messages.push({ role: 'user', content: message });

    // Call OpenAI Chat API
    const completion = await openai.createChatCompletion({
      model: 'gpt-3.5-turbo',
      messages,
    });
    const reply = completion.data.choices[0].message.content.trim();

    // Save assistant response
    await ChatMessage.create({ userId: req.user.id, role: 'assistant', message: reply });

    res.json({ reply });
  } catch (err) {
    next(err);
  }
};