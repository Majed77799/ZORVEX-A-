const Product = require('../models/Product');

// GET /api/products
exports.getProducts = async (req, res, next) => {
  try {
    const products = await Product.find().sort({ createdAt: -1 }).populate('createdBy', 'name');
    res.json(products);
  } catch (err) {
    next(err);
  }
};

// GET /api/products/:id
exports.getProduct = async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id).populate('createdBy', 'name');
    if (!product) return res.status(404).json({ message: 'Product not found' });
    res.json(product);
  } catch (err) {
    next(err);
  }
};

// POST /api/products
exports.createProduct = async (req, res, next) => {
  try {
    const { name, description, price } = req.body;
    if (!name || !price || !req.file) {
      return res.status(400).json({ message: 'Name, price and file are required' });
    }
    const fileUrl = `${req.protocol}://${req.get('host')}/uploads/${req.file.filename}`;
    const product = new Product({
      name,
      description,
      price,
      fileUrl,
      createdBy: req.user.id,
    });
    await product.save();
    res.status(201).json(product);
  } catch (err) {
    next(err);
  }
};