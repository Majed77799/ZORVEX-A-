const multer = require('multer');
const path = require('path');

// Storage configuration: store files in uploads folder with unique names
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    const ext = path.extname(file.originalname);
    const base = path.basename(file.originalname, ext);
    const uniqueName = base.replace(/\s+/g, '-') + '-' + Date.now() + ext;
    cb(null, uniqueName);
  },
});

// File filter: accept all file types.  You can restrict by mimetype if needed.
const fileFilter = function (req, file, cb) {
  cb(null, true);
};

const upload = multer({ storage, fileFilter });

module.exports = upload;