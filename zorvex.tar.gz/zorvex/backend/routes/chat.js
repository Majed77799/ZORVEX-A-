const router = require('express').Router();
const chatController = require('../controllers/chatController');
const { authenticateToken } = require('../middleware/auth');

// Chat endpoint: send a message and receive an assistant reply
router.post('/', authenticateToken, chatController.sendMessage);

module.exports = router;