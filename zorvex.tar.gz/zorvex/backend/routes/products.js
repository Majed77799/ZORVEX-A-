const router = require('express').Router();
const productController = require('../controllers/productController');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const upload = require('../middleware/upload');

// Public routes
router.get('/', productController.getProducts);
router.get('/:id', productController.getProduct);

// Admin only: create product with file upload
router.post('/', authenticateToken, requireAdmin, upload.single('file'), productController.createProduct);

module.exports = router;