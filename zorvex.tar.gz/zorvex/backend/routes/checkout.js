const router = require('express').Router();
const { authenticateToken } = require('../middleware/auth');
const checkoutController = require('../controllers/checkoutController');

router.post('/create-session', authenticateToken, checkoutController.createCheckoutSession);

module.exports = router;