# Zorvex AI Digital Product System

Zorvex is a full‑stack SaaS boilerplate built to help you launch a digital product marketplace quickly.  It provides product management with file uploads, AI‑powered chat support, Stripe checkout for monetisation, multi‑language support and a ready‑to‑deploy architecture using **Next.js** on the frontend and **Express/MongoDB** on the backend.

## Features

- **Product catalogue** – list, view and create products with description, price and an attached digital file for download.  Products are stored in MongoDB and uploaded files are saved to the server’s `uploads/` folder.
- **User authentication** – register and login with JWT‑based sessions.  Passwords are hashed with bcrypt and secured by middleware.
- **Stripe integration** – create a checkout session for a selected product.  Upon successful payment, the user will be redirected to a success page and will be able to download the purchased file.
- **AI chat bot** – a simple OpenAI‑powered chat handler that uses the ChatGPT API to answer questions.  Conversation history is persisted in MongoDB.
- **i18n (English/Arabic)** – the frontend uses [react‑i18next](https://react.i18next.com/) to provide translations.  You can extend the locales folder with your own strings.
- **Scalable architecture** – separate frontend and backend services, JWT auth middleware, modular controllers/routes and an environment configuration system.

## Repository structure

```
zorvex/
├── backend/             # Express API server
│   ├── controllers/     # Route handlers (products, auth, chat, checkout)
│   ├── middleware/      # JWT auth and file upload configuration
│   ├── models/          # Mongoose schemas
│   ├── routes/          # Express routers
│   ├── uploads/         # Uploaded product files (ignored by git)
│   ├── .env.example     # Environment variable template
│   └── server.js        # Express bootstrap and MongoDB connection
├── frontend/            # Next.js application
│   ├── components/      # Reusable UI components
│   ├── pages/           # Next.js pages (products, chat, auth)
│   ├── public/          # Static assets
│   ├── i18n.js          # i18n configuration
│   └── next.config.js   # Next.js config with i18n domains
└── README.md            # This file
```

## Getting started

### Prerequisites

* Node.js 18+ and npm
* A running MongoDB instance
* Stripe account and API keys
* An OpenAI API key

### Setup

1. Clone the repository and install dependencies for both backend and frontend:

   ```bash
   git clone <your‑fork‑url>
   cd zorvex/backend
   npm install
   cd ../frontend
   npm install
   ```

2. Copy the `.env.example` file in `backend/` to `.env` and fill in your configuration values:

   ```bash
   cp zorvex/backend/.env.example zorvex/backend/.env
   # Edit zorvex/backend/.env and set
   # MONGO_URI=your‑mongodb‑connection
   # JWT_SECRET=some‑long‑secret
   # OPENAI_API_KEY=sk‑...
   # STRIPE_SECRET_KEY=sk_live_...
   # CLIENT_URL=http://localhost:3000  # address of the frontend
   ```

3. Start the backend server:

   ```bash
   cd zorvex/backend
   npm start
   ```

   The API will run on `http://localhost:4000` by default.

4. Start the frontend in another terminal:

   ```bash
   cd zorvex/frontend
   npm run dev
   ```

   The Next.js app will be available at `http://localhost:3000`.

5. Open your browser and visit the **Products** page.  Create a new product via the **New Product** button.  Try chatting via the **Chat** page and purchase a product with Stripe checkout.

## Deployment

The project is designed to run in separate containers or services.  For production you can deploy the backend to services like Fly.io, Heroku or a custom VPS, and the frontend to Vercel.  Make sure to update the `CLIENT_URL` and CORS configuration in the backend to reflect the correct domain.  Use environment variables to store secrets and never commit them to version control.
